# 从梯度下降到共轭梯度

从五点差分系统出发，推导最速下降、共轭方向与Krylov空间，再用预条件、数值实验、成本模型及矩阵自由实现连接实际求解。

## 编译 PDF

需要 Python 3.10+ 与已安装的 XeLaTeX。所用宏包为 Beamer、fontspec、xeCJK、ctex、amsmath、amssymb、booktabs、array、TikZ、listings。图表的矢量 PDF 已包含在 figures 中。

```text
python prepare-fonts.py
xelatex -halt-on-error -interaction=nonstopmode main.tex
xelatex -halt-on-error -interaction=nonstopmode main.tex
```

字体入口按固定清单校验并配置Fandol和Latin Modern。已有精确缓存时可加`--offline`；只按字体文件编译时可加`--no-install`，返回2且报告`cache_ready=true`即可继续TeX编译。字体及来源许可保存在font-support/assets/fonts中。

## 数据和图表

- `experiment.py`：GD、CG、Jacobi-PCG、Line-PCG，网格加密与谱聚集实验。
- `figures.py`：由data中的结果绘制原始七组矢量图。
- `extension_figures.py`：PDE核对、坐标变换、矩阵自由乘法检查与求解计时。
- `refine_timing.py`：按保存的计时数据绘制对数点图及重复求解成本模型。
- `data/results.json`、`data/extension.json`、CSV：数值结果与完整迭代轨迹。
- `sources.md`：理论与API资料。

重新计算与绘图需要NumPy、SciPy、Matplotlib。该数据使用NumPy 2.3.5、SciPy 1.18.1；计时设备为Windows 11、Intel Core Ultra 7 268V，线程环境设置为1。求解时间为预热后7次测量的中位数；重复求解图按准备时间加R倍单次求解时间计算。

```text
python experiment.py
python figures.py
python extension_figures.py
python refine_timing.py
```

数学实验使用float64和明确随机种子。完整数值参数及环境记录见data。重新测时后，data/timing-table.tex同步更新，表格随再次编译使用新的数值。
