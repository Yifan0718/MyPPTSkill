# 理论与算法资料

1. Jonathan Richard Shewchuk. *An Introduction to the Conjugate Gradient Method Without the Agonizing Pain*. 1994. [作者原文](https://www.cs.cmu.edu/~quake-papers/painless-conjugate-gradient.pdf)。二次能量、最速下降、共轭方向、误差多项式、条件数界与预条件。
2. Richard Barrett et al. *Templates for the Solution of Linear Systems: Building Blocks for Iterative Methods*. Second edition. [Netlib全文](https://netlib.org/templates/templates.pdf)。PCG递推见§2.3.1，Jacobi与块Jacobi见§3.2，停止准则见§4.2。
3. [Netlib：Block Jacobi Methods](https://www.netlib.org/linalg/html_templates/node56.html)。按物理变量或二维网格的线分块。
4. [SciPy：cg](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.cg.html)。SPD条件、逆预条件算子M、rtol/atol与回调接口。
5. [SciPy：minres](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.minres.html)。对称不定系统的残差最小化。
6. [SciPy：gmres](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.gmres.html)。一般线性系统、重启与逆预条件接口。

图表数据来自 `experiment.py` 中定义的教学系统。设 $T=\operatorname{tridiag}(-1,2,-1)$、$L=I\otimes T+0.01T\otimes I$、$A=SLS$；$S$ 的对角元沿每行由1几何增至20。$m=16,32,64$，真相对残差阈值 $10^{-8}$。谱聚集实验使用120维对角系统与 $10^{-10}$ 阈值。

7. [SciPy：cho_solve_banded](https://docs.scipy.org/doc/scipy/reference/generated/scipy.linalg.cho_solve_banded.html)。带状Cholesky因子与多右端求解。
8. [SciPy：LinearOperator](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.LinearOperator.html)。使用矩阵向量乘法定义算子。
