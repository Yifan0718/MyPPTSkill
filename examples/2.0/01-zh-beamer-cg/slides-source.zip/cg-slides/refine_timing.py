"""Render stored timing measurements without rerunning the benchmark."""
from pathlib import Path
import json
import numpy as np
from figures import plt,save,grid,C
root=Path(__file__).resolve().parent
result=json.loads((root/'data/extension.json').read_text())['timing']['methods']
fig,axs=plt.subplots(1,2,figsize=(8.1,1.95),gridspec_kw={'width_ratios':[1,1.25]})
names=list(result)
for i,name in enumerate(names):
    value=result[name]['solve_ms']
    axs[0].plot(value,i,'o',color=C.get(name,'#8864a0'),ms=5)
axs[0].set(yticks=range(4),yticklabels=names,xscale='log',xlim=(.3,80),ylim=(3.5,-.5),
           xlabel='Solve time / ms (log scale)',title='(a) Measured solve time')
grid(axs[0])
R=np.arange(1,21)
for name in ['Line-PCG','Sparse LU']:
    d=result[name]
    axs[1].plot(R,d['setup_ms']+R*d['solve_ms'],label=name,color=C.get(name,'#8864a0'))
axs[1].set(xlabel='Number of right-hand sides R',ylabel='Total time / ms',
           title='(b) Setup + repeated-solve cost model',xticks=[1,5,10,15,20])
axs[1].legend(frameon=False);grid(axs[1]);fig.tight_layout(w_pad=1.8)
save(fig,'timing')
