from pathlib import Path
import json
import numpy as np
from scipy.stats import chi2,norm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
R=Path(__file__).resolve().parents[1];FOLDER=R/'figures';D=R/'data'
FOLDER.mkdir(exist_ok=True);D.mkdir(exist_ok=True)
BLUE='#2B507C';RED='#93232C';TEAL='#168578';GRAY='#7D8793'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':15,'axes.labelsize':16,'axes.titlesize':16,'xtick.labelsize':14,'ytick.labelsize':14,'legend.fontsize':13,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#A8ADB3','axes.linewidth':.7,'lines.linewidth':1.8,'pdf.fonttype':42,'axes.labelcolor':'#282B30','text.color':'#282B30'})
def finish(fig,name):
 fig.tight_layout(pad=.7,w_pad=1.5);fig.savefig(FOLDER/(name+'.png'),dpi=220,facecolor='white');fig.savefig(FOLDER/(name+'.pdf'),facecolor='white');plt.close(fig)
def grid(ax):ax.grid(alpha=.18);ax.set_axisbelow(True)
F=np.array([[1.,1.],[0.,1.]]);H=np.array([[1.,0.]]);G=np.array([.5,1.]);TRUE_Q=.2;MEAS_R=9.
def simulate(seed=2718,steps=100):
 rng=np.random.default_rng(seed);truth=np.zeros((steps,2));truth[0]=[0,1]
 for k in range(1,steps):truth[k]=F@truth[k-1]+G*rng.normal(0,np.sqrt(TRUE_Q))
 z=truth[:,0]+rng.normal(0,3,steps);return truth,z
def kalman(z,q=.2,r=9.,missing=(),gate=None):
 x=np.array([0.,1.]);P=np.diag([25.,4.]);xs=[];Ps=[];ys=[];Ss=[];Ks=[];accepted=[]
 for k,obs in enumerate(z):
  if k:x=F@x;P=F@P@F.T+q*np.outer(G,G)
  y=float(obs-x[0]);s=float(P[0,0]+r);K=P[:,0]/s;ok=k not in missing and (gate is None or y*y/s<=gate)
  ys.append(y);Ss.append(s);Ks.append(K.copy());accepted.append(ok)
  if ok:
   x=x+K*y;A=np.eye(2)-K[:,None]@H;P=A@P@A.T+r*np.outer(K,K)
  xs.append(x.copy());Ps.append(P.copy())
 return {'x':np.array(xs),'P':np.array(Ps),'y':np.array(ys),'S':np.array(Ss),'K':np.array(Ks),'accepted':np.array(accepted)}
truth,z=simulate();t=np.arange(len(z));base=kalman(z);burn=10
rmse=lambda a:float(np.sqrt(np.mean(np.square(a))))
metrics={'N':100,'dt_s':1,'seed':2718,'q':TRUE_Q,'R':MEAS_R,'rmse_after_step':burn,'measurement_rmse_m':rmse(z[burn:]-truth[burn:,0]),'position_rmse_m':rmse(base['x'][burn:,0]-truth[burn:,0]),'velocity_rmse_m_s':rmse(base['x'][burn:,1]-truth[burn:,1]),'difference_velocity_rmse_m_s':rmse(np.diff(z)[burn-1:]-truth[burn:,1])}
fig,ax=plt.subplots(figsize=(10.8,3.2));ax.plot(t,truth[:,0],color=BLUE,label='True position');ax.scatter(t,z,s=10,color=GRAY,alpha=.7,label='Position measurements');ax.set(xlabel='Time / s',ylabel='Position / m');ax.legend(frameon=False,ncol=2,loc='upper left');grid(ax);finish(fig,'measurements')
# Scalar Gaussian fusion, independently normalised product.
v=np.linspace(3,20,600);post_mu=10+4/13*3;post_var=36/13
fig,ax=plt.subplots(figsize=(5.4,3.3));ax.plot(v,norm.pdf(v,10,2),label='Prior',color=BLUE);ax.plot(v,norm.pdf(v,13,3),label='Measurement',color=GRAY);ax.plot(v,norm.pdf(v,post_mu,np.sqrt(post_var)),label='Posterior',color=RED);ax.set(xlabel='Position / m',ylabel='Density');ax.legend(frameon=False);grid(ax);finish(fig,'fusion')
metrics['scalar']={'K':4/13,'posterior_mean':post_mu,'posterior_variance':post_var}
P0=np.diag([4.,1.]);xp=F@np.array([10.,2.]);Pp=F@P0@F.T+.04*np.outer(G,G);S=float(Pp[0,0]+9);K=Pp[:,0]/S;xu=xp+K;A=np.eye(2)-K[:,None]@H;Pu=A@Pp@A.T+9*np.outer(K,K)
metrics['worked']={'prior_state':[10,2],'predicted_state':xp.tolist(),'predicted_P':Pp.tolist(),'innovation':1,'S':S,'K':K.tolist(),'posterior_state':xu.tolist(),'posterior_P':Pu.tolist()}
fig,ax=plt.subplots(figsize=(5.4,3.3))
for cov,col,label in [(P0,GRAY,'Prior'),(Pp,BLUE,'Predict'),(Pu,RED,'Update')]:
 vals,vec=np.linalg.eigh(cov);ang=np.degrees(np.arctan2(vec[1,1],vec[0,1]));e=Ellipse((0,0),2*np.sqrt(chi2.ppf(.95,2)*vals[1]),2*np.sqrt(chi2.ppf(.95,2)*vals[0]),angle=ang,fill=False,edgecolor=col,lw=1.8,label=label);ax.add_patch(e)
ax.set(xlim=(-6,6),ylim=(-3,3),xlabel='Position error / m',ylabel='Velocity error / (m/s)');ax.legend(frameon=False,fontsize=12,loc='lower center',bbox_to_anchor=(.5,1.01),ncol=3);grid(ax);finish(fig,'ellipses')
fig,axs=plt.subplots(1,2,figsize=(10.8,3.1));axs[0].plot(t,base['x'][:,0]-truth[:,0],color=RED);sigma=np.sqrt(base['P'][:,0,0]);axs[0].fill_between(t,-1.96*sigma,1.96*sigma,color=RED,alpha=.12,label='Marginal 95% interval');axs[0].set(xlabel='Time / s',ylabel='Position error / m');axs[0].legend(frameon=False,fontsize=12);axs[1].plot(t[1:],np.diff(z),color=GRAY,alpha=.55,label='Difference of measurements');axs[1].plot(t,truth[:,1],color=BLUE,label='True velocity');axs[1].plot(t,base['x'][:,1],color=RED,label='Filtered velocity');axs[1].set(xlabel='Time / s',ylabel='Velocity / (m/s)');axs[1].legend(frameon=False,fontsize=11)
for ax in axs:grid(ax)
finish(fig,'results')
fig,axs=plt.subplots(1,2,figsize=(10.8,3.1));axs[0].plot(t,base['y']/np.sqrt(base['S']),color=BLUE);axs[0].axhline(0,color=GRAY,lw=.8);axs[0].axhline(1.96,color=RED,ls='--',lw=1);axs[0].axhline(-1.96,color=RED,ls='--',lw=1);axs[0].set(xlabel='Time / s',ylabel='Innovation / SD');axs[1].plot(t,base['K'][:,0],label='Position gain',color=RED);axs[1].plot(t,base['K'][:,1],label='Velocity gain (1/s)',color=TEAL);axs[1].set(xlabel='Time / s',ylabel='Gain component');axs[1].legend(frameon=False,fontsize=12)
for ax in axs:grid(ax)
finish(fig,'innovation_gain')
qs=[.002,.2,2.];tuning=[];fig,axs=plt.subplots(1,2,figsize=(10.8,3.1))
for q,col in zip(qs,[GRAY,RED,TEAL]):
 a=kalman(z,q=q);tuning.append({'q':q,'position_rmse':rmse(a['x'][burn:,0]-truth[burn:,0]),'velocity_rmse':rmse(a['x'][burn:,1]-truth[burn:,1])});axs[0].plot(t,a['x'][:,0]-truth[:,0],color=col,label=f'q = {q:g}');axs[1].plot(t,a['x'][:,1],color=col)
axs[0].set(xlabel='Time / s',ylabel='Position error / m');axs[0].legend(frameon=False,fontsize=12,ncol=3);axs[1].plot(t,truth[:,1],color=BLUE,ls='--',label='True velocity');axs[1].set(xlim=(40,80),xlabel='Time / s',ylabel='Velocity / (m/s)');axs[1].legend(frameon=False)
for ax in axs:grid(ax)
finish(fig,'q_tuning');metrics['q_tuning']=tuning
missing=range(40,51);drop=kalman(z,missing=missing);fig,axs=plt.subplots(1,2,figsize=(10.8,3.1));axs[0].plot(t,truth[:,0],color=BLUE,label='True position');axs[0].plot(t,drop['x'][:,0],color=RED,label='Estimate');axs[0].scatter(t[[k not in missing for k in t]],z[[k not in missing for k in t]],s=9,color=GRAY);axs[0].set(xlim=(30,62),xlabel='Time / s',ylabel='Position / m');axs[0].legend(frameon=False,fontsize=12);axs[1].plot(t,np.sqrt(drop['P'][:,0,0]),color=RED);axs[1].set(xlim=(30,62),xlabel='Time / s',ylabel='Position SD / m')
for ax in axs:ax.axvspan(40,50,color=GRAY,alpha=.15);grid(ax)
finish(fig,'dropout');metrics['dropout']={'sd_step39':float(np.sqrt(drop['P'][39,0,0])),'sd_step50':float(np.sqrt(drop['P'][50,0,0])),'sd_step51':float(np.sqrt(drop['P'][51,0,0]))}
zo=z.copy();zo[65]+=30;ung=kalman(zo);gate=chi2.ppf(.99,1);gated=kalman(zo,gate=gate);fig,ax=plt.subplots(figsize=(10.8,3.1));ax.plot(t,truth[:,0],color=BLUE,label='True');ax.plot(t,ung['x'][:,0],color=GRAY,label='Always update');ax.plot(t,gated['x'][:,0],color=RED,label='99% innovation gate');ax.scatter(t,zo,s=10,color=TEAL,label='Measurements');ax.set(xlim=(58,75),xlabel='Time / s',ylabel='Position / m');ax.legend(frameon=False,ncol=4,fontsize=12);grid(ax);finish(fig,'outlier');metrics['outlier']={'threshold':float(gate),'NIS_step65':float(ung['y'][65]**2/ung['S'][65]),'accepted_step65':bool(gated['accepted'][65]),'rejected_steps':np.where(~gated['accepted'])[0].tolist()}
# Monte Carlo, matched dynamics, compare assumed measurement covariance.
mc=[];nis_values={r:[] for r in [1.,9.,36.]};cover={r:[] for r in nis_values}
for seed in range(400):
 tr,zz=simulate(10000+seed)
 for r in nis_values:
  f=kalman(zz,r=r);nis_values[r].extend((f['y'][burn:]**2/f['S'][burn:]).tolist());cover[r].extend((abs(f['x'][burn:,0]-tr[burn:,0])<=1.96*np.sqrt(f['P'][burn:,0,0])).tolist())
for r in nis_values:mc.append({'assumed_R':r,'mean_NIS':float(np.mean(nis_values[r])),'position_95_coverage':float(np.mean(cover[r]))})
metrics['monte_carlo']={'trials':400,'samples_per_trial':90,'results':mc}
fig,axs=plt.subplots(1,2,figsize=(10.8,3.1));axs[0].bar(['R = 1','R = 9','R = 36'],[v['mean_NIS'] for v in mc],color=[GRAY,RED,TEAL]);axs[0].axhline(1,color=BLUE,ls='--');axs[0].set(ylabel='Mean NIS');axs[1].bar(['R = 1','R = 9','R = 36'],[100*v['position_95_coverage'] for v in mc],color=[GRAY,RED,TEAL]);axs[1].axhline(95,color=BLUE,ls='--');axs[1].set(ylim=(0,105),ylabel='Coverage / %')
for ax in axs:grid(ax)
finish(fig,'consistency')
np.savez(D/'tracking.npz',time=t,truth=truth,measurement=z,estimate=base['x'],covariance=base['P'],innovation=base['y'],innovation_variance=base['S'])
assert all(np.linalg.eigvalsh(v).min()>-1e-10 for v in base['P']);assert np.max(abs(base['P']-base['P'].transpose(0,2,1)))<1e-12
assert abs(post_mu-10.923076923076923)<1e-12;assert metrics['outlier']['accepted_step65'] is False
(D/'results.json').write_text(json.dumps(metrics,indent=2),encoding='utf8');print(json.dumps(metrics,indent=2))
