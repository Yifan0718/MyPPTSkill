"""Reproducible float64 experiments for the conjugate-gradient lecture.
Run: python experiment.py. Outputs are numerical data, not benchmark timings.
"""
from pathlib import Path
import json
import numpy as np
from scipy import sparse, linalg
from scipy.sparse.linalg import cg, LinearOperator, eigsh

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'data'
OUT.mkdir(exist_ok=True)

def pcg(A, b, apply=None, tol=1e-8, maxiter=10000, exact=None):
    apply = apply or (lambda x: x.copy())
    x = np.zeros_like(b); r = b.copy(); z = apply(r); p = z.copy()
    rho = r @ z; bn = np.linalg.norm(b)
    if np.linalg.norm(r) == 0:
        return x, np.array([[0., 0., 0., 0. if exact is not None else np.nan]])
    en0 = np.sqrt(exact @ (A @ exact)) if exact is not None else 1
    history = [[0, 1., 1., 1.]]
    for k in range(1, maxiter+1):
        q = A @ p; alpha = rho/(p @ q)
        x += alpha*p; r -= alpha*q
        true = np.linalg.norm(b-A@x)/bn
        en = np.sqrt(max(0,(exact-x)@(A@(exact-x))))/en0 if exact is not None else np.nan
        history.append([k, np.linalg.norm(r)/bn, true, en])
        if true <= tol: break
        z = apply(r); rho_new = r @ z
        p = z + (rho_new/rho)*p; rho = rho_new
    return x, np.array(history)

def problem(m, eps=.01, scale=20):
    T=sparse.diags([-np.ones(m-1),2*np.ones(m),-np.ones(m-1)],[-1,0,1],format='csr')
    L=sparse.kron(sparse.eye(m),T,format='csr')+eps*sparse.kron(T,sparse.eye(m),format='csr')
    s=np.tile(np.geomspace(1,scale,m),m)
    S=sparse.diags(s); A=(S@L@S).tocsr()
    # m independent x-direction lines. Cholesky factor reused for every row.
    band=np.zeros((2,m)); band[0]=2+2*eps; band[1,:-1]=-1
    chol=linalg.cholesky_banded(band,lower=True)
    def line(r):
        u=(r/s).reshape(m,m).T
        return linalg.cho_solve_banded((chol,True),u).T.ravel()/s
    jac=lambda r:r/A.diagonal()
    exact=np.random.default_rng(20261111).normal(size=m*m)
    return A,L,s,exact,A@exact,jac,line

def main():
    result={'seed':20261111,'dtype':'float64','epsilon':.01,'scale_range':[1,20],
            'tolerance':1e-8,'starting_vector':'zeros','rhs':'b = A @ standard_normal(seed)', 'mesh':[]}
    for m in [16,32,64]:
        A,L,s,exact,b,jac,line=problem(m)
        row={'m':m,'n':m*m,'nnz':A.nnz,'methods':{}}
        for name,apply in [('CG',None),('Jacobi-PCG',jac),('Line-PCG',line)]:
            x,h=pcg(A,b,apply,exact=exact)
            np.savetxt(OUT/f'm{m}_{name}.csv',h,delimiter=',',header='iteration,recursive_relative_residual,true_relative_residual,relative_A_error',comments='')
            row['methods'][name]={'iterations':int(h[-1,0]),'true_relative_residual':h[-1,2], 'relative_A_error':h[-1,3]}
            op=LinearOperator(A.shape,matvec=apply) if apply else None
            sx,info=cg(A,b,rtol=1e-8,atol=0,M=op)
            assert info == 0 and np.linalg.norm(A@sx-b)/np.linalg.norm(b)<1.01e-8
            assert np.linalg.norm(x-sx)/np.linalg.norm(sx)<1e-7
        theta=np.pi*np.arange(1,m+1)/(m+1); lam=2-2*np.cos(theta)
        transformed=(lam[:,None]+.01*lam[None,:])/(lam[:,None]+.02)
        row['kappa_Jacobi']=float(lam[-1]/lam[0])
        row['kappa_Line']=float(transformed.max()/transformed.min())
        if m == 32:
            vals=linalg.eigvalsh(A.toarray())
            row['kappa_A']=float(vals[-1]/vals[0]); np.save(OUT/'eigenvalues_A.npy',vals)
            x=np.zeros_like(b); history=[]; bn=np.linalg.norm(b); en0=np.sqrt(exact@(A@exact))
            for k in range(10001):
                r=b-A@x; er=exact-x
                history.append([k,np.linalg.norm(r)/bn,np.sqrt(max(0,er@(A@er)))/en0])
                if k<10000: x+=(r@r)/(r@(A@r))*r
            np.savetxt(OUT/'m32_GD.csv',history,delimiter=',',header='iteration,true_relative_residual,relative_A_error',comments='')
            row['methods']['GD']={'iterations':10000,'true_relative_residual':history[-1][1],'relative_A_error':history[-1][2]}
            sparse.save_npz(OUT/'A_m32.npz',A); np.save(OUT/'scale_m32.npy',s)
        result['mesh'].append(row)
    # Same condition number, different spectral structure, equal initial A-energy per mode.
    for name,lam in [('spread',np.geomspace(1,1000,120)),('clustered',np.r_[1.,np.linspace(100,101,118),1000.])]:
        D=sparse.diags(lam); exact=1/np.sqrt(lam); b=lam*exact
        _,h=pcg(D,b,tol=1e-10,exact=exact)
        np.savetxt(OUT/f'spectrum_{name}.csv',h,delimiter=',',header='iteration,recursive_relative_residual,true_relative_residual,relative_A_error',comments='')
        np.savetxt(OUT/f'eigenvalues_{name}.csv',lam,delimiter=',')
        result[name]={'iterations':int(h[-1,0]),'relative_A_error':h[-1,3]}
    # Exact-arithmetic two-dimensional teaching example, verified numerically.
    A=np.array([[4.,1.],[1.,3.]]); b=np.array([1.,2.]); exact=np.linalg.solve(A,b)
    _,h=pcg(A,b,tol=1e-14,exact=exact)
    result['two_dimensional']={'A':A.tolist(),'b':b.tolist(),'solution':exact.tolist(),'history':h.tolist()}
    (OUT/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__ == '__main__': main()
