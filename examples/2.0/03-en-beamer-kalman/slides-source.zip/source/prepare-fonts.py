#!/usr/bin/env python3
"""Prepare exact presentation fonts using the accompanying public resources."""
from pathlib import Path
import runpy
import sys

root = Path(__file__).resolve().parent
script = root / "font-support/scripts/setup_fonts.py"
sys.argv = [str(script), "--project-dir", str(root), *sys.argv[1:]]
runpy.run_path(str(script), run_name="__main__")
