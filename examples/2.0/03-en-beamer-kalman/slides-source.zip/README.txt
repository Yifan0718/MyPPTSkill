How Kalman Filters Track Noisy Motion
Author: SKILL Application Test
20-slide Beamer presentation, including the cover.

Compile from the source directory:
  cd source
  python prepare-fonts.py
  latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex

The font entry restores the exact managed font files and creates a local
myppt-fonts.tex. A cache_ready result with exit code 2 supports direct TeX
font-file loading. Font licenses and checksums are in font-support.

TeX dependencies: Beamer, fontspec, xeCJK, unicode-math, TikZ, PGFPlots,
listings, booktabs, amsmath, amssymb and latexmk.
All figures are included as PDF and PNG. The numerical data and the fixed-seed
experiment source are included. Recreate figures with NumPy, SciPy and
Matplotlib by running python source/experiment.py from this directory.
