"""Additional lecture figures and independently executable numerical checks."""
import os
for key in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):
    os.environ[key]='1'
from pathlib import Path
import json,time,platform
import numpy as np
import scipy
from scipy import sparse,linalg
from scipy.sparse.linalg import cg,LinearOperator,splu
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from figures import save,grid,C
from experiment import problem

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'data'

def pde():
    m=32;h=1/(m+1);v=np.arange(1,m+1)*h;X,Y=np.meshgrid(v,v)
    truth=np.sin(np.pi*X)*np.sin(np.pi*Y)
    f=1.01*np.pi**2*truth
    A,L,s,_,_,_,_=problem(m,scale=1)
    x,info=cg(L,h*h*f.ravel(),rtol=1e-12,atol=0)
    assert info==0
    sol=x.reshape(m,m)
    fig,axs=plt.subplots(1,2,figsize=(7.1,2.5))
    for ax,Z,title in zip(axs,[f,sol],['(a) Source f(x, y)','(b) Discrete solution u']):
        im=ax.imshow(Z,origin='lower',extent=(0,1,0,1),cmap='viridis',vmin=0)
        ax.set(xlabel='x',ylabel='y',title=title)
        fig.colorbar(im,ax=ax,fraction=.045,pad=.04)
    fig.tight_layout(w_pad=1);save(fig,'pde')
    return {'m':m,'max_error':float(np.max(np.abs(sol-truth))),'true_relative_residual':float(np.linalg.norm(L@x-h*h*f.ravel())/np.linalg.norm(h*h*f.ravel()))}

def linesearch():
    A=np.array([[4.,1.],[1.,3.]]);b=np.array([1.,2.]);r=b
    a=np.linspace(0,.55,201);val=.5*a*a*(r@A@r)-a*(r@r)
    fig,ax=plt.subplots(figsize=(3.5,2.7));ax.plot(a,val,color=C['CG'])
    ax.axvline(.25,color=C['Line-PCG'],ls='--',lw=1)
    ax.plot(.25,-.625,'o',color=C['Line-PCG']);ax.annotate(r'$\alpha_*=1/4$',(.25,-.625),xytext=(12,25),textcoords='offset points')
    ax.set(xlabel=r'Step length $\alpha$',ylabel=r'$f(x_0+\alpha r_0)$');grid(ax);fig.tight_layout();save(fig,'linesearch')

def transformed():
    B=np.array([[2.,-1.],[-1.,2.]]);S=np.diag([10.,1.]);A=S@B@S
    P=np.diag(np.diag(A));D=np.diag(1/np.sqrt(np.diag(P)));H=D@A@D
    fig,axs=plt.subplots(1,2,figsize=(7.1,2.6))
    for ax,M,labels,title in zip(axs,[A,H],[('x1','x2'),('y1','y2')],['(a) Original coordinates','(b) Diagonally scaled coordinates']):
        vals,Q=np.linalg.eigh(M);t=np.linspace(0,2*np.pi,350)
        for c in [.3,.7,1.2,1.8]:
            xy=Q@np.diag(1/np.sqrt(vals))@np.array([np.cos(t),np.sin(t)])*c
            ax.plot(xy[0],xy[1],color=C['CG'] if M is A else C['Line-PCG'],alpha=.8)
        ax.set(xlim=(-2.7,2.7),ylim=(-2.7,2.7),aspect='equal',xlabel=labels[0],ylabel=labels[1],title=title)
        ax.axhline(0,color='#ccd0d3',lw=.5);ax.axvline(0,color='#ccd0d3',lw=.5)
        ax.tick_params(labelsize=12)
        ax.xaxis.label.set_size(12);ax.yaxis.label.set_size(12);ax.title.set_size(12)
    fig.tight_layout(w_pad=2);save(fig,'transformed')
    return {'kappa_original':float(np.linalg.cond(A)),'kappa_scaled':float(np.linalg.cond(H))}

def matrixfree_check():
    m=32;eps=.01;A,L,s,exact,b,jac,line=problem(m)
    def matvec(v):
        U=(s*v).reshape(m,m)
        V=(2+2*eps)*U.copy()
        V[:,:-1]-=U[:,1:];V[:,1:]-=U[:,:-1]
        V[:-1,:]-=eps*U[1:,:];V[1:,:]-=eps*U[:-1,:]
        return s*V.ravel()
    rng=np.random.default_rng(103);v=rng.normal(size=m*m)
    relative=np.linalg.norm(matvec(v)-A@v)/np.linalg.norm(A@v)
    assert relative<1e-14
    op=LinearOperator(A.shape,matvec=matvec,dtype=np.float64)
    M=LinearOperator(A.shape,matvec=line,dtype=np.float64)
    x,info=cg(op,b,M=M,rtol=1e-8,atol=0)
    res=np.linalg.norm(A@x-b)/np.linalg.norm(b)
    assert info==0 and res<1e-8
    return {'matvec_relative_difference':float(relative),'cg_true_relative_residual':float(res)}

def timing():
    m=64;eps=.01;A,L,s,exact,b,_,_=problem(m)
    def make(name):
        if name=='CG': return lambda: cg(A,b,rtol=1e-8,atol=0,maxiter=5000)
        if name=='Jacobi-PCG':
            d=A.diagonal();M=LinearOperator(A.shape,matvec=lambda r:r/d,dtype=np.float64)
        elif name=='Line-PCG':
            band=np.zeros((2,m));band[0]=2+2*eps;band[1,:-1]=-1
            factor=linalg.cholesky_banded(band,lower=True)
            def apply(r):return linalg.cho_solve_banded((factor,True),(r/s).reshape(m,m).T).T.ravel()/s
            M=LinearOperator(A.shape,matvec=apply,dtype=np.float64)
        else:
            factor=splu(A.tocsc())
            return lambda:(factor.solve(b),0)
        return lambda:cg(A,b,M=M,rtol=1e-8,atol=0,maxiter=5000)
    result={}
    for name in ['CG','Jacobi-PCG','Line-PCG','Sparse LU']:
        make(name)();setups=[];solves=[]
        for _ in range(7):
            t=time.perf_counter();solve=make(name);setups.append((time.perf_counter()-t)*1e3)
            t=time.perf_counter();x,info=solve();solves.append((time.perf_counter()-t)*1e3)
            assert info==0 and np.linalg.norm(A@x-b)/np.linalg.norm(b)<1.01e-8
        result[name]={'setup_ms':float(np.median(setups)),'solve_ms':float(np.median(solves))}
    fig,axs=plt.subplots(1,2,figsize=(7.4,2.2),gridspec_kw={'width_ratios':[1,1.25]})
    names=list(result);color=[C.get(n,'#8864a0') for n in names]
    axs[0].barh(names,[result[n]['solve_ms'] for n in names],color=color)
    axs[0].invert_yaxis();axs[0].set(xlabel='Solve time / ms',title='(a) One solve after setup',xscale='log');grid(axs[0])
    R=np.arange(1,21)
    for name in ['Line-PCG','Sparse LU']:
        d=result[name];axs[1].plot(R,d['setup_ms']+R*d['solve_ms'],label=name,color=C.get(name,'#8864a0'))
    axs[1].set(xlabel='Number of right-hand sides R',ylabel='Total time / ms',title='(b) Reusing the same matrix',xticks=[1,5,10,15,20]);grid(axs[1]);axs[1].legend(frameon=False)
    fig.tight_layout(w_pad=1.5);save(fig,'timing')
    return {'m':m,'n':m*m,'repeats':7,'statistic':'median','numpy':np.__version__,'scipy':scipy.__version__,
            'platform':platform.platform(),'processor':platform.processor(),'thread_environment':{k:os.environ[k] for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS')},'methods':result}

if __name__=='__main__':
    results={'pde':pde(),'coordinate_scaling':transformed(),'matrixfree':matrixfree_check(),'timing':timing()}
    linesearch()
    (OUT/'extension.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
    timing=results['timing']['methods']
    rows=[]
    for label,key in [('准备','setup_ms'),('单次求解','solve_ms')]:
        rows.append(label+' & '+' & '.join(f"{timing[name][key]:.3f}" for name in ['CG','Jacobi-PCG','Line-PCG','Sparse LU'])+r'\\')
    table=r'\begin{tabular}{lrrrr}\toprule'+'\n'+r'方法 & CG & Jacobi-PCG & Line-PCG & 稀疏LU\\\midrule'+'\n'+'\n'.join(rows)+'\n'+r'\bottomrule\end{tabular}'+'\n'
    (OUT/'timing-table.tex').write_text(table,encoding='utf8')
    print(json.dumps(results,ensure_ascii=False,indent=2))
